from flask import Flask, render_template, request, redirect, url_for, flash, session
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Change for security

# Set the directory for saving uploaded profile pictures
UPLOAD_FOLDER = 'static/uploads'  # Ensure this directory exists
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Create the uploads directory if it doesn't exist
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Simple dictionary structure as a user database (a real application would require a database)
users = {}

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login_post():
    username = request.form['username']
    password = request.form['password']
    
    # Username and password verification
    if username in users and users[username]['password'] == password:
        session['username'] = username
        flash("Login successful!", "success")
        return redirect(url_for('home'))  # Redirect to home page
    else:
        flash("Invalid username or password.", "error")
        return redirect(url_for('login'))

@app.route('/register')
def register():
    return render_template('register.html')

@app.route('/register', methods=['POST'])
def register_post():
    username = request.form['username']
    password = request.form['password']
    confirm_password = request.form['confirm_password']
    phone = request.form['phone']

    # Check if the username already exists
    if username in users:
        flash("This username already exists.", "error")
        return redirect(url_for('register'))

    # Check if passwords match
    if password != confirm_password:
        flash("Passwords do not match. Please try again.", "error")
        return redirect(url_for('register'))

    # Handle profile picture upload
    profile_picture = request.files.get('profile_picture')
    if profile_picture:
        if profile_picture.filename == '':
            flash("No selected file.", "error")
            return redirect(url_for('register'))

        # Secure the filename and save it
        picture_filename = secure_filename(profile_picture.filename)
        profile_picture.save(os.path.join(app.config['UPLOAD_FOLDER'], picture_filename))
    else:
        flash("Profile picture is required.", "error")
        return redirect(url_for('register'))

    # Save new user
    users[username] = {
        'password': password,
        'phone': phone,
        'profile_picture': picture_filename,
        'messages': []  # Initialize message list
    }
    flash("Registration successful! You can log in.", "success")
    return redirect(url_for('login'))

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'username' not in session:
        flash("Please log in.", "error")
        return redirect(url_for('login'))
    
    username = session['username']
    user = users.get(username)  # Use get to avoid errors
    
    if user is None:
        flash("User not found.", "error")
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        # Update phone number
        new_phone = request.form['phone']
        users[username]['phone'] = new_phone
        flash("Your phone number has been updated!", "success")
        return redirect(url_for('profile'))
    
    return render_template('profile.html', username=username, phone=user['phone'], profile_picture=user['profile_picture'])

@app.route('/home', methods=['GET'])
def home():
    if 'username' not in session:
        flash("Please log in.", "error")
        return redirect(url_for('login'))

    # Pass users to the home template for display
    return render_template('home.html', users=users)

@app.route('/dm', methods=['GET', 'POST'])
def dm():
    if 'username' not in session:
        flash("Please log in.", "error")
        return redirect(url_for('login'))

    username = session['username']
    user = users.get(username)

    # Check if the user exists in the database
    if user is None:
        flash("User not found.", "error")
        return redirect(url_for('home'))

    if request.method == 'POST':
        recipient = request.form['recipient']
        message_content = request.form['message']
        
        if recipient in users:
            # Append the message to the recipient's messages
            users[recipient]['messages'].append({'sender': username, 'content': message_content})
            flash("Message sent!", "success")
        else:
            flash("User not found.", "error")
        return redirect(url_for('dm'))

    # Combine received and sent messages into one list
    all_messages = user.get('messages', [])
    for recipient, details in users.items():
        if recipient != username:
            all_messages.extend(
                {'sender': username, 'content': msg['content'], 'recipient': recipient}
                for msg in details.get('messages', [])
                if msg['sender'] == username
            )

    return render_template('dm.html', username=username, users=users, all_messages=all_messages)

@app.route('/logout')
def logout():
    session.pop('username', None)
    flash("You have successfully logged out.", "success")
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='ibos.tiiny.site', debug=True)
